/**
 * api.js — central API config for PharmaCare Django backend
 * All fetch calls go through the helpers below.
 */

const API_BASE = 'http://127.0.0.1:8000/api';

// ── Auth helpers ──────────────────────────────────────────────
function getToken() {
    return localStorage.getItem('authToken');
}

function authHeaders() {
    const token = getToken();
    return {
        'Content-Type': 'application/json',
        ...(token ? { 'Authorization': `Bearer ${token}` } : {})
    };
}

async function apiFetch(path, options = {}) {
    const res = await fetch(`${API_BASE}${path}`, {
        ...options,
        headers: { ...authHeaders(), ...(options.headers || {}) }
    });

    // Only redirect on 401 if user was previously logged in
    if (res.status === 401 && getToken()) {
        localStorage.removeItem('authToken');
        localStorage.removeItem('currentUser');
        window.location.href = '/pro1/login.html';
        return;
    }

    const data = await res.json();
    if (!res.ok) throw data;
    return data;
}

// ── Auth ──────────────────────────────────────────────────────
const AuthAPI = {
    register: (payload) =>
        apiFetch('/auth/register', { method: 'POST', body: JSON.stringify(payload) }),

    login: (payload) =>
        apiFetch('/auth/login', { method: 'POST', body: JSON.stringify(payload) }),

    verify: () => apiFetch('/auth/verify'),
};

// ── Medicines ─────────────────────────────────────────────────
const MedicinesAPI = {
    list: (params = {}) => {
        const qs = new URLSearchParams(params).toString();
        return apiFetch(`/medicines${qs ? '?' + qs : ''}`);
    },

    search: (q, extra = {}) =>
        MedicinesAPI.list({ search: q, ...extra }),

    detail: (id) => apiFetch(`/medicines/${id}`),

    categories: () => apiFetch('/medicines/categories/list'),
};

// ── Pharmacies ────────────────────────────────────────────────
const PharmaciesAPI = {
    list: (params = {}) => {
        const qs = new URLSearchParams(params).toString();
        return apiFetch(`/pharmacies${qs ? '?' + qs : ''}`);
    },

    detail: (id)    => apiFetch(`/pharmacies/${id}`),
    reviews: (id)   => apiFetch(`/pharmacies/${id}/reviews`),

    addReview: (id, payload) =>
        apiFetch(`/pharmacies/${id}/reviews`, { method: 'POST', body: JSON.stringify(payload) }),
};

// ── Orders ────────────────────────────────────────────────────
const OrdersAPI = {
    list: (params = {}) => {
        const qs = new URLSearchParams(params).toString();
        return apiFetch(`/orders${qs ? '?' + qs : ''}`);
    },

    create: (payload) =>
        apiFetch('/orders', { method: 'POST', body: JSON.stringify(payload) }),

    detail: (id)  => apiFetch(`/orders/${id}`),

    updateStatus: (id, payload) =>
        apiFetch(`/orders/${id}`, { method: 'PATCH', body: JSON.stringify(payload) }),

    cancel: (id)  => apiFetch(`/orders/${id}`, { method: 'DELETE' }),

    stats: ()     => apiFetch('/orders/stats/summary'),
};

// ── Feedback ──────────────────────────────────────────────────
const FeedbackAPI = {
    submit: (payload) =>
        apiFetch('/feedback', { method: 'POST', body: JSON.stringify(payload) }),

    list: () => apiFetch('/feedback/mine'),

    recent: () => apiFetch('/feedback/recent'),

    detail: (id) => apiFetch(`/feedback/${id}`),

    categories: () => Promise.resolve([
        { value: 'general',  label: 'General' },
        { value: 'medicine', label: 'Medicine' },
        { value: 'pharmacy', label: 'Pharmacy' },
        { value: 'delivery', label: 'Delivery' },
        { value: 'app',      label: 'App / Website' },
        { value: 'other',    label: 'Other' },
    ]),
};
