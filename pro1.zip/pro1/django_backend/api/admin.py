from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
from .models import User, Pharmacy, Medicine, PharmacyMedicine, Order, OrderItem, Review, Feedback

admin.site.register(User, BaseUserAdmin)
admin.site.register(Pharmacy)
admin.site.register(Medicine)
admin.site.register(PharmacyMedicine)
admin.site.register(Order)
admin.site.register(OrderItem)
admin.site.register(Review)


@admin.register(Feedback)
class FeedbackAdmin(admin.ModelAdmin):
    list_display = ['id', 'subject', 'category', 'status', 'user', 'name', 'created_at']
    list_filter = ['status', 'category']
    search_fields = ['subject', 'message', 'name', 'email']
    readonly_fields = ['created_at', 'updated_at']
