from django.urls import path
from rest_framework_simplejwt.views import TokenRefreshView
from .views.auth import RegisterView, LoginView, VerifyTokenView
from .views.medicines import MedicineListView, MedicineDetailView, MedicineSearchView, MedicineCategoriesView
from .views.pharmacies import PharmacyListView, PharmacyDetailView, PharmacySearchView, PharmacyReviewView
from .views.orders import OrderListView, OrderDetailView, OrderStatsView
from .views.users import (
    UserProfileView, ChangePasswordView, UserOrdersView,
    UserReviewsView, DeleteAccountView, UserDashboardView,
)
from .views.feedback import FeedbackSubmitView, MyFeedbackView, RecentFeedbackView, AdminFeedbackListView, AdminFeedbackDetailView
from django.http import JsonResponse
from django.utils import timezone


def health_check(request):
    return JsonResponse({
        'status': 'OK',
        'message': 'PharmaCare API is running',
        'timestamp': timezone.now().isoformat(),
        'version': '2.0.0',
    })


urlpatterns = [
    # Health
    path('health', health_check),

    # Auth
    path('auth/register', RegisterView.as_view()),
    path('auth/login', LoginView.as_view()),
    path('auth/verify', VerifyTokenView.as_view()),
    path('auth/refresh', TokenRefreshView.as_view()),

    # Medicines
    path('medicines', MedicineListView.as_view()),
    path('medicines/search', MedicineSearchView.as_view()),
    path('medicines/categories/list', MedicineCategoriesView.as_view()),
    path('medicines/<int:pk>', MedicineDetailView.as_view()),

    # Pharmacies
    path('pharmacies', PharmacyListView.as_view()),
    path('pharmacies/search', PharmacySearchView.as_view()),
    path('pharmacies/<int:pk>', PharmacyDetailView.as_view()),
    path('pharmacies/<int:pk>/reviews', PharmacyReviewView.as_view()),

    # Orders
    path('orders', OrderListView.as_view()),
    path('orders/stats/summary', OrderStatsView.as_view()),
    path('orders/<int:pk>', OrderDetailView.as_view()),

    # Users
    path('users/profile', UserProfileView.as_view()),
    path('users/password', ChangePasswordView.as_view()),
    path('users/orders', UserOrdersView.as_view()),
    path('users/reviews', UserReviewsView.as_view()),
    path('users/account', DeleteAccountView.as_view()),
    path('users/dashboard', UserDashboardView.as_view()),

    # Feedback — customer
    path('feedback', FeedbackSubmitView.as_view()),
    path('feedback/mine', MyFeedbackView.as_view()),
    path('feedback/recent', RecentFeedbackView.as_view()),

    # Feedback — admin CRUD
    path('admin/feedback', AdminFeedbackListView.as_view()),
    path('admin/feedback/<int:pk>', AdminFeedbackDetailView.as_view()),
]
