from rest_framework import serializers
from django.contrib.auth import get_user_model
from .models import Pharmacy, Medicine, PharmacyMedicine, Order, OrderItem, Review

User = get_user_model()


class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['id', 'username', 'email', 'phone', 'address', 'date_joined']


class RegisterSerializer(serializers.ModelSerializer):
    password = serializers.CharField(write_only=True, min_length=6)

    class Meta:
        model = User
        fields = ['username', 'email', 'password', 'phone', 'address']

    def create(self, validated_data):
        return User.objects.create_user(**validated_data)


class ChangePasswordSerializer(serializers.Serializer):
    current_password = serializers.CharField(write_only=True)
    new_password = serializers.CharField(write_only=True, min_length=6)


class PharmacySerializer(serializers.ModelSerializer):
    medicine_count = serializers.IntegerField(read_only=True, default=0)
    avg_rating = serializers.FloatField(read_only=True, default=0)
    review_count = serializers.IntegerField(read_only=True, default=0)
    distance = serializers.FloatField(read_only=True, required=False)

    class Meta:
        model = Pharmacy
        fields = [
            'id', 'name', 'address', 'phone', 'email',
            'latitude', 'longitude', 'opening_hours', 'is_24_hours',
            'rating', 'description', 'image', 'created_at',
            'medicine_count', 'avg_rating', 'review_count', 'distance',
        ]


class MedicineSerializer(serializers.ModelSerializer):
    pharmacy_count = serializers.IntegerField(read_only=True, default=0)
    min_price = serializers.DecimalField(max_digits=10, decimal_places=2, read_only=True, allow_null=True)
    max_price = serializers.DecimalField(max_digits=10, decimal_places=2, read_only=True, allow_null=True)
    avg_price = serializers.DecimalField(max_digits=10, decimal_places=2, read_only=True, allow_null=True)

    class Meta:
        model = Medicine
        fields = [
            'id', 'name', 'brand', 'category', 'description',
            'dosage', 'side_effects', 'requires_prescription', 'image', 'created_at',
            'pharmacy_count', 'min_price', 'max_price', 'avg_price',
        ]


class PharmacyMedicineSerializer(serializers.ModelSerializer):
    medicine = MedicineSerializer(read_only=True)
    medicine_id = serializers.PrimaryKeyRelatedField(
        queryset=Medicine.objects.all(), source='medicine', write_only=True
    )

    class Meta:
        model = PharmacyMedicine
        fields = ['id', 'medicine', 'medicine_id', 'price', 'stock_quantity', 'availability_status', 'updated_at']


class ReviewSerializer(serializers.ModelSerializer):
    username = serializers.CharField(source='user.username', read_only=True)

    class Meta:
        model = Review
        fields = ['id', 'username', 'rating', 'comment', 'created_at']
        read_only_fields = ['id', 'username', 'created_at']

    def validate_rating(self, value):
        if not 1 <= value <= 5:
            raise serializers.ValidationError("Rating must be between 1 and 5.")
        return value


class OrderItemSerializer(serializers.ModelSerializer):
    medicine_name = serializers.CharField(source='medicine.name', read_only=True)
    brand = serializers.CharField(source='medicine.brand', read_only=True)
    category = serializers.CharField(source='medicine.category', read_only=True)

    class Meta:
        model = OrderItem
        fields = ['id', 'medicine_id', 'medicine_name', 'brand', 'category', 'quantity', 'unit_price', 'total_price']


class OrderSerializer(serializers.ModelSerializer):
    items = OrderItemSerializer(many=True, read_only=True)
    pharmacy_name = serializers.CharField(source='pharmacy.name', read_only=True)
    pharmacy_address = serializers.CharField(source='pharmacy.address', read_only=True)
    pharmacy_phone = serializers.CharField(source='pharmacy.phone', read_only=True)

    class Meta:
        model = Order
        fields = [
            'id', 'pharmacy_id', 'pharmacy_name', 'pharmacy_address', 'pharmacy_phone',
            'total_amount', 'status', 'delivery_address', 'phone',
            'payment_method', 'payment_status', 'notes', 'created_at', 'updated_at', 'items',
        ]
        read_only_fields = ['id', 'total_amount', 'status', 'payment_status', 'created_at', 'updated_at']


class CreateOrderSerializer(serializers.Serializer):
    pharmacy_id = serializers.IntegerField()
    delivery_address = serializers.CharField(required=False, allow_blank=True)
    phone = serializers.CharField(required=False, allow_blank=True)
    payment_method = serializers.ChoiceField(choices=['telebirr', 'cash', 'bank_transfer'], default='telebirr')
    notes = serializers.CharField(required=False, allow_blank=True)
    items = serializers.ListField(
        child=serializers.DictField(),
        min_length=1
    )


# ── Feedback ──────────────────────────────────────────────────────────────────

from .models import Feedback


class FeedbackSerializer(serializers.ModelSerializer):
    """Used by customers to submit feedback (read-only status/admin_reply)."""
    username = serializers.CharField(source='user.username', read_only=True, default=None)
    pharmacy_name = serializers.CharField(source='pharmacy.name', read_only=True, default=None)
    medicine_name = serializers.CharField(source='medicine.name', read_only=True, default=None)

    class Meta:
        model = Feedback
        fields = [
            'id', 'username', 'name', 'email',
            'category', 'subject', 'message', 'rating',
            'pharmacy', 'pharmacy_name', 'medicine', 'medicine_name',
            'status', 'admin_reply', 'created_at',
        ]
        read_only_fields = ['id', 'username', 'status', 'admin_reply', 'created_at',
                            'pharmacy_name', 'medicine_name']

    def validate_rating(self, value):
        if value is not None and not (1 <= value <= 5):
            raise serializers.ValidationError("Rating must be between 1 and 5.")
        return value


class AdminFeedbackSerializer(serializers.ModelSerializer):
    """Full serializer for admin — can update status and reply."""
    username = serializers.CharField(source='user.username', read_only=True, default=None)
    pharmacy_name = serializers.CharField(source='pharmacy.name', read_only=True, default=None)
    medicine_name = serializers.CharField(source='medicine.name', read_only=True, default=None)

    class Meta:
        model = Feedback
        fields = [
            'id', 'username', 'name', 'email',
            'category', 'subject', 'message', 'rating',
            'pharmacy', 'pharmacy_name', 'medicine', 'medicine_name',
            'status', 'admin_reply', 'created_at', 'updated_at',
        ]
        read_only_fields = ['id', 'username', 'created_at', 'updated_at',
                            'pharmacy_name', 'medicine_name']
