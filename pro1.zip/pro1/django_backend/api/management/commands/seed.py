from django.core.management.base import BaseCommand
from api.models import User, Pharmacy, Medicine, PharmacyMedicine


class Command(BaseCommand):
    help = 'Seed the database with sample data'

    def handle(self, *args, **kwargs):
        self.stdout.write('Seeding pharmacies...')
        pharmacies_data = [
            {'name': 'Kombolcha Central Pharmacy', 'address': 'Main Street, Near Hospital, Kombolcha',
             'phone': '+251911234567', 'email': 'central@pharmacy.et', 'latitude': 11.0815, 'longitude': 39.7267,
             'rating': 4.8, 'is_24_hours': True, 'description': 'The largest pharmacy in Kombolcha with 24/7 service'},
            {'name': 'Dessie Road Pharmacy', 'address': 'Dessie Road, Near Bus Station, Kombolcha',
             'phone': '+251911234568', 'email': 'dessie@pharmacy.et', 'latitude': 11.0845, 'longitude': 39.7298,
             'rating': 4.6, 'is_24_hours': False, 'description': 'Convenient location near transportation hub'},
            {'name': 'Wollo University Pharmacy', 'address': 'University Campus, Kombolcha',
             'phone': '+251911234569', 'email': 'uni@pharmacy.et', 'latitude': 11.0789, 'longitude': 39.7234,
             'rating': 4.7, 'is_24_hours': False, 'description': 'Serving university community'},
            {'name': 'Express Pharmacy', 'address': 'Commercial District, Kombolcha',
             'phone': '+251911234571', 'email': 'express@pharmacy.et', 'latitude': 11.0832, 'longitude': 39.7289,
             'rating': 4.5, 'is_24_hours': True, 'description': 'Fast service with home delivery'},
        ]
        pharmacies = []
        for p in pharmacies_data:
            obj, _ = Pharmacy.objects.get_or_create(name=p['name'], defaults=p)
            pharmacies.append(obj)

        self.stdout.write('Seeding medicines...')
        medicines_data = [
            {'name': 'Paracetamol 500mg', 'brand': 'Panadol', 'category': 'Pain Relief',
             'description': 'Effective pain relief and fever reducer', 'requires_prescription': False},
            {'name': 'Ibuprofen 400mg', 'brand': 'Advil', 'category': 'Pain Relief',
             'description': 'Anti-inflammatory pain reliever', 'requires_prescription': False},
            {'name': 'Amoxicillin 250mg', 'brand': 'Amoxil', 'category': 'Antibiotic',
             'description': 'Broad-spectrum antibiotic', 'requires_prescription': True},
            {'name': 'Omeprazole 20mg', 'brand': 'Losec', 'category': 'Digestive',
             'description': 'Acid reflux treatment', 'requires_prescription': False},
            {'name': 'Cetirizine 10mg', 'brand': 'Zyrtec', 'category': 'Allergy',
             'description': 'Antihistamine for allergies', 'requires_prescription': False},
            {'name': 'Metformin 500mg', 'brand': 'Glucophage', 'category': 'Diabetes',
             'description': 'Type 2 diabetes medication', 'requires_prescription': True},
        ]
        medicines = []
        for m in medicines_data:
            obj, _ = Medicine.objects.get_or_create(name=m['name'], defaults=m)
            medicines.append(obj)

        self.stdout.write('Seeding inventory...')
        import random
        for pharmacy in pharmacies:
            for medicine in medicines:
                PharmacyMedicine.objects.get_or_create(
                    pharmacy=pharmacy,
                    medicine=medicine,
                    defaults={
                        'price': round(random.uniform(10, 200), 2),
                        'stock_quantity': random.randint(10, 100),
                        'availability_status': 'In Stock',
                    }
                )

        self.stdout.write('Seeding users...')
        for username, email in [('john_doe', 'john@example.com'), ('jane_smith', 'jane@example.com')]:
            if not User.objects.filter(username=username).exists():
                User.objects.create_user(username=username, email=email, password='password123')

        self.stdout.write(self.style.SUCCESS('Database seeded successfully!'))
