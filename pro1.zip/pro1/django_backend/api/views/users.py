from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from rest_framework.permissions import IsAuthenticated
from django.db.models import Count, Sum, Case, When, IntegerField
from ..models import Order, Review, Pharmacy
from ..serializers import UserSerializer, ChangePasswordSerializer, OrderSerializer, ReviewSerializer


class UserProfileView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        stats = Order.objects.filter(user=request.user).aggregate(
            total_orders=Count('id'),
            completed_orders=Count(Case(When(status='delivered', then=1), output_field=IntegerField())),
            total_spent=Sum('total_amount'),
        )
        return Response({
            'user': UserSerializer(request.user).data,
            'statistics': stats,
        })

    def put(self, request):
        serializer = UserSerializer(request.user, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class ChangePasswordView(APIView):
    permission_classes = [IsAuthenticated]

    def put(self, request):
        serializer = ChangePasswordSerializer(data=request.data)
        if not serializer.is_valid():
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        user = request.user
        if not user.check_password(serializer.validated_data['current_password']):
            return Response({'error': 'Current password is incorrect'}, status=status.HTTP_400_BAD_REQUEST)

        user.set_password(serializer.validated_data['new_password'])
        user.save()
        return Response({'message': 'Password updated successfully'})


class UserOrdersView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        orders = Order.objects.filter(user=request.user).select_related('pharmacy').prefetch_related(
            'items__medicine'
        ).order_by('-created_at')
        return Response({'orders': OrderSerializer(orders, many=True).data})


class UserReviewsView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        reviews = Review.objects.filter(user=request.user).select_related('pharmacy')
        return Response({'reviews': ReviewSerializer(reviews, many=True).data})


class DeleteAccountView(APIView):
    permission_classes = [IsAuthenticated]

    def delete(self, request):
        password = request.data.get('password')
        if not password or not request.user.check_password(password):
            return Response({'error': 'Invalid password'}, status=status.HTTP_400_BAD_REQUEST)
        request.user.is_active = False
        request.user.save()
        return Response({'message': 'Account deactivated successfully'})


class UserDashboardView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        recent_orders = Order.objects.filter(user=request.user).select_related('pharmacy').prefetch_related(
            'items__medicine'
        ).order_by('-created_at')[:5]

        stats = Order.objects.filter(user=request.user).aggregate(
            total_orders=Count('id'),
            completed_orders=Count(Case(When(status='delivered', then=1), output_field=IntegerField())),
            total_spent=Sum('total_amount'),
        )

        # Favorite pharmacies (most ordered from)
        fav_pharmacies = (
            Order.objects.filter(user=request.user)
            .values('pharmacy__id', 'pharmacy__name', 'pharmacy__address', 'pharmacy__phone')
            .annotate(order_count=Count('id'))
            .order_by('-order_count')[:3]
        )

        return Response({
            'recent_orders': OrderSerializer(recent_orders, many=True).data,
            'statistics': stats,
            'favorite_pharmacies': list(fav_pharmacies),
        })
