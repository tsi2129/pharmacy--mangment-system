import math
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from rest_framework.permissions import AllowAny, IsAuthenticated
from django.db.models import Count, Avg, Q
from ..models import Pharmacy, PharmacyMedicine, Review
from ..serializers import PharmacySerializer, PharmacyMedicineSerializer, ReviewSerializer


def haversine(lat1, lon1, lat2, lon2):
    """Return distance in km between two coordinates."""
    R = 6371
    dlat = math.radians(float(lat2) - float(lat1))
    dlon = math.radians(float(lon2) - float(lon1))
    a = (math.sin(dlat / 2) ** 2 +
         math.cos(math.radians(float(lat1))) * math.cos(math.radians(float(lat2))) *
         math.sin(dlon / 2) ** 2)
    return R * 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))


class PharmacyListView(APIView):
    permission_classes = [AllowAny]

    def get(self, request):
        lat = request.query_params.get('lat')
        lng = request.query_params.get('lng')
        radius = float(request.query_params.get('radius', 10))
        limit = int(request.query_params.get('limit', 50))
        offset = int(request.query_params.get('offset', 0))

        qs = Pharmacy.objects.filter(is_active=True).annotate(
            medicine_count=Count('inventory__medicine', distinct=True),
            avg_rating=Avg('reviews__rating'),
            review_count=Count('reviews', distinct=True),
        )

        pharmacies = list(qs)

        if lat and lng:
            for p in pharmacies:
                if p.latitude and p.longitude:
                    p.distance = haversine(lat, lng, p.latitude, p.longitude)
                else:
                    p.distance = None
            pharmacies = [p for p in pharmacies if p.distance is not None and p.distance <= radius]
            pharmacies.sort(key=lambda p: p.distance)
        else:
            for p in pharmacies:
                p.distance = None
            pharmacies.sort(key=lambda p: p.name)

        total = len(pharmacies)
        page = pharmacies[offset:offset + limit]

        return Response({
            'pharmacies': PharmacySerializer(page, many=True).data,
            'pagination': {'total': total, 'limit': limit, 'offset': offset},
        })


class PharmacyDetailView(APIView):
    permission_classes = [AllowAny]

    def get(self, request, pk):
        try:
            pharmacy = Pharmacy.objects.annotate(
                medicine_count=Count('inventory__medicine', distinct=True),
                avg_rating=Avg('reviews__rating'),
                review_count=Count('reviews', distinct=True),
            ).get(pk=pk, is_active=True)
        except Pharmacy.DoesNotExist:
            return Response({'error': 'Pharmacy not found'}, status=status.HTTP_404_NOT_FOUND)

        medicines = PharmacyMedicine.objects.filter(pharmacy=pharmacy).select_related('medicine')
        reviews = Review.objects.filter(pharmacy=pharmacy).select_related('user').order_by('-created_at')[:10]

        return Response({
            'pharmacy': PharmacySerializer(pharmacy).data,
            'medicines': PharmacyMedicineSerializer(medicines, many=True).data,
            'reviews': ReviewSerializer(reviews, many=True).data,
        })


class PharmacySearchView(APIView):
    permission_classes = [AllowAny]

    def post(self, request):
        query = request.data.get('query', '')
        is_24_hours = request.data.get('is_24_hours')
        min_rating = request.data.get('min_rating')
        lat = request.data.get('lat')
        lng = request.data.get('lng')
        radius = float(request.data.get('radius', 10))
        limit = int(request.data.get('limit', 50))
        offset = int(request.data.get('offset', 0))

        qs = Pharmacy.objects.filter(is_active=True).annotate(
            medicine_count=Count('inventory__medicine', distinct=True),
            avg_rating=Avg('reviews__rating'),
            review_count=Count('reviews', distinct=True),
        )

        if query:
            qs = qs.filter(Q(name__icontains=query) | Q(address__icontains=query))
        if is_24_hours is not None:
            qs = qs.filter(is_24_hours=is_24_hours)
        if min_rating:
            qs = qs.filter(rating__gte=min_rating)

        pharmacies = list(qs)

        if lat and lng:
            for p in pharmacies:
                if p.latitude and p.longitude:
                    p.distance = haversine(lat, lng, p.latitude, p.longitude)
                else:
                    p.distance = None
            pharmacies = [p for p in pharmacies if p.distance is not None and p.distance <= radius]
            pharmacies.sort(key=lambda p: p.distance)
        else:
            for p in pharmacies:
                p.distance = None

        total = len(pharmacies)
        page = pharmacies[offset:offset + limit]

        return Response({
            'pharmacies': PharmacySerializer(page, many=True).data,
            'pagination': {'total': total, 'limit': limit, 'offset': offset},
        })


class PharmacyReviewView(APIView):

    def get_permissions(self):
        if self.request.method == 'GET':
            return [AllowAny()]
        return [IsAuthenticated()]

    def get(self, request, pk):
        try:
            pharmacy = Pharmacy.objects.get(pk=pk, is_active=True)
        except Pharmacy.DoesNotExist:
            return Response({'error': 'Pharmacy not found'}, status=status.HTTP_404_NOT_FOUND)

        reviews = Review.objects.filter(pharmacy=pharmacy).select_related('user').order_by('-created_at')
        avg = reviews.aggregate(avg=Avg('rating'))

        return Response({
            'reviews': ReviewSerializer(reviews, many=True).data,
            'stats': {
                'total': reviews.count(),
                'average_rating': avg['avg'],
            },
        })

    def post(self, request, pk):
        try:
            pharmacy = Pharmacy.objects.get(pk=pk, is_active=True)
        except Pharmacy.DoesNotExist:
            return Response({'error': 'Pharmacy not found'}, status=status.HTTP_404_NOT_FOUND)

        review, created = Review.objects.get_or_create(user=request.user, pharmacy=pharmacy)
        serializer = ReviewSerializer(review, data=request.data, partial=not created)
        if serializer.is_valid():
            serializer.save(user=request.user, pharmacy=pharmacy)
            return Response(serializer.data, status=status.HTTP_201_CREATED if created else status.HTTP_200_OK)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
