from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from rest_framework.permissions import AllowAny, IsAuthenticated
from django.db.models import Count, Min, Max, Avg, Q
from ..models import Medicine, PharmacyMedicine
from ..serializers import MedicineSerializer, PharmacyMedicineSerializer


class MedicineListView(APIView):
    permission_classes = [AllowAny]

    def get(self, request):
        category = request.query_params.get('category')
        search = request.query_params.get('search')
        limit = int(request.query_params.get('limit', 50))
        offset = int(request.query_params.get('offset', 0))

        qs = Medicine.objects.filter(is_active=True).annotate(
            pharmacy_count=Count('pharmacy_stock', distinct=True),
            min_price=Min('pharmacy_stock__price'),
            max_price=Max('pharmacy_stock__price'),
            avg_price=Avg('pharmacy_stock__price'),
        )

        if category:
            qs = qs.filter(category=category)

        if search:
            qs = qs.filter(
                Q(name__icontains=search) |
                Q(brand__icontains=search) |
                Q(description__icontains=search)
            )

        total = qs.count()
        medicines = qs.order_by('name')[offset:offset + limit]

        return Response({
            'medicines': MedicineSerializer(medicines, many=True).data,
            'pagination': {'total': total, 'limit': limit, 'offset': offset},
        })

    def post(self, request):
        if not request.user.is_authenticated:
            return Response({'error': 'Authentication required'}, status=status.HTTP_401_UNAUTHORIZED)
        serializer = MedicineSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class MedicineDetailView(APIView):
    permission_classes = [AllowAny]

    def get(self, request, pk):
        try:
            medicine = Medicine.objects.annotate(
                pharmacy_count=Count('pharmacy_stock', distinct=True),
                min_price=Min('pharmacy_stock__price'),
                max_price=Max('pharmacy_stock__price'),
                avg_price=Avg('pharmacy_stock__price'),
            ).get(pk=pk, is_active=True)
        except Medicine.DoesNotExist:
            return Response({'error': 'Medicine not found'}, status=status.HTTP_404_NOT_FOUND)

        # Pharmacy availability
        availability = PharmacyMedicine.objects.filter(
            medicine=medicine
        ).select_related('pharmacy').order_by('price')

        return Response({
            'medicine': MedicineSerializer(medicine).data,
            'availability': PharmacyMedicineSerializer(availability, many=True).data,
        })


class MedicineSearchView(APIView):
    permission_classes = [AllowAny]

    def post(self, request):
        query = request.data.get('query', '')
        category = request.data.get('category')
        min_price = request.data.get('min_price')
        max_price = request.data.get('max_price')
        requires_prescription = request.data.get('requires_prescription')
        sort_by = request.data.get('sort_by', 'name')
        limit = int(request.data.get('limit', 50))
        offset = int(request.data.get('offset', 0))

        qs = Medicine.objects.filter(is_active=True).annotate(
            pharmacy_count=Count('pharmacy_stock', distinct=True),
            min_price=Min('pharmacy_stock__price'),
            max_price=Max('pharmacy_stock__price'),
            avg_price=Avg('pharmacy_stock__price'),
        )

        if query:
            qs = qs.filter(
                Q(name__icontains=query) |
                Q(brand__icontains=query) |
                Q(description__icontains=query)
            )
        if category:
            qs = qs.filter(category=category)
        if requires_prescription is not None:
            qs = qs.filter(requires_prescription=requires_prescription)
        if min_price:
            qs = qs.filter(pharmacy_stock__price__gte=min_price)
        if max_price:
            qs = qs.filter(pharmacy_stock__price__lte=max_price)

        sort_map = {'name': 'name', 'price': 'min_price', '-price': '-min_price'}
        qs = qs.order_by(sort_map.get(sort_by, 'name'))

        total = qs.count()
        medicines = qs[offset:offset + limit]

        return Response({
            'medicines': MedicineSerializer(medicines, many=True).data,
            'pagination': {'total': total, 'limit': limit, 'offset': offset},
        })


class MedicineCategoriesView(APIView):
    permission_classes = [AllowAny]

    def get(self, request):
        categories = (
            Medicine.objects.filter(is_active=True, category__isnull=False)
            .values_list('category', flat=True)
            .distinct()
            .order_by('category')
        )
        return Response({'categories': list(categories)})
