from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from rest_framework.permissions import IsAuthenticated, IsAdminUser, AllowAny
from ..models import Feedback
from ..serializers import FeedbackSerializer, AdminFeedbackSerializer


# ── Customer views ────────────────────────────────────────────────────────────

class FeedbackSubmitView(APIView):
    """POST /api/feedback — anyone can submit (logged-in or anonymous)."""
    permission_classes = [AllowAny]

    def post(self, request):
        serializer = FeedbackSerializer(data=request.data)
        if not serializer.is_valid():
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        user = request.user if request.user.is_authenticated else None

        # Anonymous users must supply name + email
        if not user:
            if not request.data.get('name') or not request.data.get('email'):
                return Response(
                    {'error': 'name and email are required for anonymous feedback'},
                    status=status.HTTP_400_BAD_REQUEST
                )

        serializer.save(user=user)
        return Response(
            {'message': 'Feedback submitted successfully', 'feedback': serializer.data},
            status=status.HTTP_201_CREATED
        )


class MyFeedbackView(APIView):
    """GET /api/feedback/mine — authenticated user sees their own history."""
    permission_classes = [IsAuthenticated]

    def get(self, request):
        feedbacks = Feedback.objects.filter(user=request.user)
        return Response({'feedbacks': FeedbackSerializer(feedbacks, many=True).data})


class RecentFeedbackView(APIView):
    """GET /api/feedback/recent — public list of resolved feedback (for sidebar display)."""
    permission_classes = [AllowAny]

    def get(self, request):
        feedbacks = Feedback.objects.filter(
            status='resolved'
        ).exclude(admin_reply='').order_by('-created_at')[:5]
        return Response({'feedbacks': FeedbackSerializer(feedbacks, many=True).data})


# ── Admin views ───────────────────────────────────────────────────────────────

class AdminFeedbackListView(APIView):
    """
    GET  /api/admin/feedback  — list all feedback (filter by status/category/search)
    POST /api/admin/feedback  — create feedback entry
    """
    permission_classes = [IsAdminUser]

    def get(self, request):
        qs = Feedback.objects.all()

        fb_status = request.query_params.get('status')
        category  = request.query_params.get('category')
        search    = request.query_params.get('search')

        if fb_status:
            qs = qs.filter(status=fb_status)
        if category:
            qs = qs.filter(category=category)
        if search:
            qs = qs.filter(subject__icontains=search) | qs.filter(message__icontains=search)

        return Response({
            'count': qs.count(),
            'feedbacks': AdminFeedbackSerializer(qs, many=True).data,
        })

    def post(self, request):
        serializer = AdminFeedbackSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class AdminFeedbackDetailView(APIView):
    """
    GET    /api/admin/feedback/<id>  — retrieve
    PATCH  /api/admin/feedback/<id>  — update status / add reply
    DELETE /api/admin/feedback/<id>  — delete
    """
    permission_classes = [IsAdminUser]

    def _get(self, pk):
        try:
            return Feedback.objects.get(pk=pk)
        except Feedback.DoesNotExist:
            return None

    def get(self, request, pk):
        obj = self._get(pk)
        if not obj:
            return Response({'error': 'Feedback not found'}, status=status.HTTP_404_NOT_FOUND)
        return Response(AdminFeedbackSerializer(obj).data)

    def patch(self, request, pk):
        obj = self._get(pk)
        if not obj:
            return Response({'error': 'Feedback not found'}, status=status.HTTP_404_NOT_FOUND)
        serializer = AdminFeedbackSerializer(obj, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def put(self, request, pk):
        obj = self._get(pk)
        if not obj:
            return Response({'error': 'Feedback not found'}, status=status.HTTP_404_NOT_FOUND)
        serializer = AdminFeedbackSerializer(obj, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, pk):
        obj = self._get(pk)
        if not obj:
            return Response({'error': 'Feedback not found'}, status=status.HTTP_404_NOT_FOUND)
        obj.delete()
        return Response({'message': 'Feedback deleted'}, status=status.HTTP_204_NO_CONTENT)
