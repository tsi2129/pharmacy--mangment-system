from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from rest_framework.permissions import IsAuthenticated
from django.db import transaction
from django.db.models import Sum, Count, Case, When, IntegerField
from ..models import Order, OrderItem, Pharmacy, PharmacyMedicine, Medicine
from ..serializers import OrderSerializer, CreateOrderSerializer


class OrderListView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        order_status = request.query_params.get('status')
        limit = int(request.query_params.get('limit', 20))
        offset = int(request.query_params.get('offset', 0))

        qs = Order.objects.filter(user=request.user).select_related('pharmacy').prefetch_related('items__medicine')

        if order_status:
            qs = qs.filter(status=order_status)

        qs = qs.order_by('-created_at')
        total = qs.count()
        orders = qs[offset:offset + limit]

        return Response({
            'orders': OrderSerializer(orders, many=True).data,
            'pagination': {'total': total, 'limit': limit, 'offset': offset},
        })

    def post(self, request):
        serializer = CreateOrderSerializer(data=request.data)
        if not serializer.is_valid():
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        data = serializer.validated_data

        try:
            pharmacy = Pharmacy.objects.get(pk=data['pharmacy_id'], is_active=True)
        except Pharmacy.DoesNotExist:
            return Response({'error': 'Pharmacy not found'}, status=status.HTTP_404_NOT_FOUND)

        with transaction.atomic():
            total_amount = 0
            order_items_data = []

            for item in data['items']:
                medicine_id = item.get('medicine_id')
                quantity = int(item.get('quantity', 1))

                try:
                    inv = PharmacyMedicine.objects.select_for_update().get(
                        pharmacy=pharmacy, medicine_id=medicine_id
                    )
                except PharmacyMedicine.DoesNotExist:
                    return Response(
                        {'error': f'Medicine {medicine_id} not available at this pharmacy'},
                        status=status.HTTP_400_BAD_REQUEST
                    )

                if inv.stock_quantity < quantity:
                    return Response(
                        {'error': f'Insufficient stock for medicine {medicine_id}'},
                        status=status.HTTP_400_BAD_REQUEST
                    )

                unit_price = inv.price
                total_price = unit_price * quantity
                total_amount += total_price

                inv.stock_quantity -= quantity
                if inv.stock_quantity == 0:
                    inv.availability_status = 'Out of Stock'
                elif inv.stock_quantity <= 10:
                    inv.availability_status = 'Limited Stock'
                inv.save()

                order_items_data.append({
                    'medicine_id': medicine_id,
                    'quantity': quantity,
                    'unit_price': unit_price,
                    'total_price': total_price,
                })

            order = Order.objects.create(
                user=request.user,
                pharmacy=pharmacy,
                total_amount=total_amount,
                delivery_address=data.get('delivery_address', ''),
                phone=data.get('phone', ''),
                payment_method=data.get('payment_method', 'telebirr'),
                notes=data.get('notes', ''),
            )

            for item_data in order_items_data:
                OrderItem.objects.create(order=order, **item_data)

        return Response(OrderSerializer(order).data, status=status.HTTP_201_CREATED)


class OrderDetailView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request, pk):
        try:
            order = Order.objects.prefetch_related('items__medicine').select_related('pharmacy').get(
                pk=pk, user=request.user
            )
        except Order.DoesNotExist:
            return Response({'error': 'Order not found'}, status=status.HTTP_404_NOT_FOUND)
        return Response(OrderSerializer(order).data)

    def patch(self, request, pk):
        try:
            order = Order.objects.get(pk=pk, user=request.user)
        except Order.DoesNotExist:
            return Response({'error': 'Order not found'}, status=status.HTTP_404_NOT_FOUND)

        new_status = request.data.get('status')
        payment_status = request.data.get('payment_status')

        if new_status:
            order.status = new_status
        if payment_status:
            order.payment_status = payment_status
        order.save()

        return Response(OrderSerializer(order).data)

    def delete(self, request, pk):
        try:
            order = Order.objects.get(pk=pk, user=request.user)
        except Order.DoesNotExist:
            return Response({'error': 'Order not found'}, status=status.HTTP_404_NOT_FOUND)

        if order.status not in ('pending', 'confirmed'):
            return Response({'error': 'Cannot cancel this order'}, status=status.HTTP_400_BAD_REQUEST)

        with transaction.atomic():
            # Restore stock
            for item in order.items.select_related('medicine').all():
                try:
                    inv = PharmacyMedicine.objects.get(pharmacy=order.pharmacy, medicine=item.medicine)
                    inv.stock_quantity += item.quantity
                    inv.availability_status = 'In Stock'
                    inv.save()
                except PharmacyMedicine.DoesNotExist:
                    pass
            order.status = 'cancelled'
            order.save()

        return Response({'message': 'Order cancelled successfully'})


class OrderStatsView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        stats = Order.objects.filter(user=request.user).aggregate(
            total_orders=Count('id'),
            completed_orders=Count(Case(When(status='delivered', then=1), output_field=IntegerField())),
            total_spent=Sum('total_amount'),
        )
        return Response(stats)
